export class Categorie {
    idCat : number;
    nomCat : string;
}